class UserNotFoundError(Exception):
    pass